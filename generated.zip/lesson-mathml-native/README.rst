Some MathML examples.
