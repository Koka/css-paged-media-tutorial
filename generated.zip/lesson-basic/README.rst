This section will show some basic CSS formatting features like bold or italic
text and text in different font-sizes.
