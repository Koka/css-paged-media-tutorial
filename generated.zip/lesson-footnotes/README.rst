This example explains how to generate footnotes from HTML markup and
how to style the marker and the footnote text itself
