This example shows bitmap images and SVG graphics in original size and
scaled down together with some CSS transformations.
