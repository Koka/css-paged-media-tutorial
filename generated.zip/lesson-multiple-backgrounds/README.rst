This example renders two background images for the same element.
