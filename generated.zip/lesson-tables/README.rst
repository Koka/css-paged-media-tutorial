This lessons renders some more complex tables with running headers (table
header and footer to be repeated on each page. The CSS specs do not define
whether header and footer should/must be repeated or not and there is not CSS
property for controlling the behavior. So support or non-support for repeating
headers and footers is both a valid interpretation of the incomplete CSS specs. 
