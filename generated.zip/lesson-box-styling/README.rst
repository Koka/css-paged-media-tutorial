This example shows some text within a box with a rounded borders. 
The border of the box should be in orange and blue colors. Only
Antennahouse implements the ``box-shadow`` property used in this
example.
