This example outlines the structure of a HTML document with nested chapters.
The counters of the section are being automatically generated using CSS
counters.
