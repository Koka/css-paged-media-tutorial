In this example we evalute the hyphenation of long (German) words for different box sizes.
This example is completely artificial but it demonstrates how the converters behave with
overlong words
