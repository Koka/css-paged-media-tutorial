This examples draws 360 absolute positioned boxes with the same content but
each rotated by 1 degress.  In the end you will see some circular structure
from the texts being overprinted.
