The example shows the basic usage of arbitrary truetype or opentype fonts
using @font-face in CSS.

