This example demonstrates the basic usage of hyphenation.
Most converters come with hyphenation tables for the most frequent languages.
In this example you see text boxes with german and english text, with and without
hyphenation.
