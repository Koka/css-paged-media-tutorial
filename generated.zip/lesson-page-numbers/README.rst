Basic usage using a page counter and a counter for the total number of pages
