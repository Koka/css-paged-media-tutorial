Simple text with and without ligatures.
