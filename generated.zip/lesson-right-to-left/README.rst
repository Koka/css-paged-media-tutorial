Some hebrew text rendered right to left.
