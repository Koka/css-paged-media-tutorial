This lesson will generate PDF bookmarks for the given h1 and h2 elements.
Please note that PrinceXML can generate the PDF bookmarks directly.
PDFreactor and Antennahous require a specific CSS property (see styles.css).
