This example show a text box and and an image - both mirrored using the CSS class ``flip``.
