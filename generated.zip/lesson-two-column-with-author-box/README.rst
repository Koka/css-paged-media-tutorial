This example shows a two-column text (converted from DOCX to XML).  The text
show a left-floated author box on the first page. The PDFs generated using
PDFreactor and Antennahouse use a grid (texts inside both columns are aligned
with a baseline grid).  Footnotes are placed by Antennahouse within the same
column as the footnote appears while all other processors place footnotes below
all columns.

