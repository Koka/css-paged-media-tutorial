This example creates a chart using HTML5 and the Flotr2 JS chart engine
(http://www.humblesoftware.com/flotr2/).
