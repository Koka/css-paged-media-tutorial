In example you see the options how to fit over long text into a given
bounding box using Antennahouse's ``-ah-overflow-condense`` options.
