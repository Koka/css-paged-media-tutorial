This example renders two pages in A5 using so called "named pages".
The first named page is "Portait", the second one is "Landscape".
Named pages allow you to render a particular content element on a different
page with deviant @settings (size, orientation, page boxes).

- Page 1: text on A5 (portrait)
- Page 2: text on A5 (landscape)
- Page 3: text on A4 (landscape, blue background, custom header and footer, custom colors)
