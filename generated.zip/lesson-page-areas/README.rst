This example renders the page regions as defined in the CSS Paged Media specs.
