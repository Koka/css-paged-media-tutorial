This example shows a two-column layout with side notes place in the left and
right margin. The side note functionality is implemented using Javascript.
