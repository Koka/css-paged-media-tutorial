This example shows a two-column layout with side notes placed in the left
margin (on left pages) and right margin (on right pages). In addition this
example will demonstrate how to place some text only onto the first and lage
page. CSS Paged Media defines the ``:first`` selector but no ``:last`` selector.
PDFreactor provides the ``-ro-last`` selector as alternative. The side note
functionality is implemented using floats and Javascript.
