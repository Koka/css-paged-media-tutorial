This example should show a background image stretching over the
complete width and height of the printable area.
