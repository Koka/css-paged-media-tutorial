Stacked DIV element. 

Demo code taken from https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Positioning/Understanding_z_index/Stacking_and_float

The all outputs (see positioning of DIV #1) are correct. Vivliostyle supports
as only converter opacity and stacks the DIV elements in the same way as
browser engines do. PDFreactor, Antennahouse and PrinceXML do not support opacity
and stack the DIV elements according to the rules...so the rendering of all
converters here is at some point correct and consistent.
