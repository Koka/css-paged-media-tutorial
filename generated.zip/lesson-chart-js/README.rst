This example renders a chart using Javascript with help of the chart add-on 
chart.js (http://chartjs.org).
