This test is intended to simulate a novel with three chapters.
Every chapter should start on a right page with header and footer.
The blank (left) pages should remain completely empty (only possible
with PrinceXML and Antennahouse by using the @page:blank selector).
