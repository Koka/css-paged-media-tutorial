This example show the usage of CSS gradients
