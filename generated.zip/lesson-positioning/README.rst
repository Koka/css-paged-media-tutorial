Absolute positioning of text boxes
