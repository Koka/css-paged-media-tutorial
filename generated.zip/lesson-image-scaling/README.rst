This example show how images will be scaled into the boxes with a a given
width. Setting ``width: 100%`` on the image should auto-scale the image into
the parent box. The first two example will place the image in its original size
into the parent container. No scaling should happen. The image on the first
page should be clipped at the right border due to the ``overflow: hidden``
setting on the parent container.
