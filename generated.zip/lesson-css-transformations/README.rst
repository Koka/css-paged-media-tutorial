This example show CSS 3 transformations. It shows a text box rotated by 90,
180, 270 degree and an image rotated and scaled.

