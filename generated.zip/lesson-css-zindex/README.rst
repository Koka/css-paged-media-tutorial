This example renders three overlapping rectangles.  The red rectangle should be
drawn with 75% opacity.  It partly covers the blue and the green rectangle.
The stacking order of the rectangles is defined by their z-index.
