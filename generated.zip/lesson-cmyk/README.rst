This example shows the usage of CMYK for text and the capability to include
images with CMYK colorspace.
