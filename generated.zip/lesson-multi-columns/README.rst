This example shows some text renders in a two, three and four column layout.
The text uses english hyphenation, text is justified.
