A complex CSS example with CSS positioning, fonts and some typography.
Expected output:

.. image:: images/lesson-complex-css-expected.png


Source: http://v1.jontangerine.com/silo/css/complex-type-fix/
