This test show the usage of the :first-letter and :first-line pseudo selectors.
