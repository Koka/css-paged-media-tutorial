Example showing multiple chapters of a document with a forced page break after
each section header.
