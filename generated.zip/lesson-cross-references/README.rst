This example contains for chapters that are linked to the table of contents
where the chapter title is automatically inserted into the table of contents together
with the related page number.
